INSERT INTO products (name, price, availability) VALUES
    ('Laptop', 999.99, TRUE),
    ('Smartphone', 599.99, FALSE),
    ('Tablet', 399.99, TRUE),
    ('Desktop', 1299.99, TRUE),
    ('Smartwatch', 199.99, FALSE),
    ('Headphones', 149.99, TRUE),
    ('Camera', 799.99, TRUE),
    ('Printer', 299.99, FALSE),
    ('External Hard Drive', 129.99, TRUE),
    ('Wireless Router', 79.99, TRUE);